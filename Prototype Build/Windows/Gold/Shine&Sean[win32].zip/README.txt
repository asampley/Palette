Shine & Sean

Bug workaround:
When upon reaching level 2 and if for the client both players Sean and Shine buttons are grayed out/disabled, the client just disconnects by pressing P and go back to main menu and connect back in.
This should allow the client to pick a character again.
Meanwhile the host should keep hosting and wait for the client.

